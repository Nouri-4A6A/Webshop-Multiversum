<?php
  require_once 'model/MultimediaLogic.php';

  class MultimediaController {
    public function __construct() {
      $this->ProductsLogic = new ProductsLogic();
}

  public function handleRequest() {
    if (isset($_GET['op'])) {

      $op = $_GET['op'];

    } else {
      $op = '';
    }

    switch ($op) {
      case 'create':
          $this->collect();
          echo "Yoohoo it works lmao haha funny it works yay yippie";
          break;
      case 'read':
          $this->collect();
          echo "read";
          break;
      case 'update':
          echo "updated";
          break;
      case 'delete':
          echo "deleted";
          break;
          default:
          $this->collect
          break;
    }
  }
    public function collect() {
      $ = $this->ProductsLogic->createProduct();
    }

    public function collectReadProduct() {
      $ = $this->ProductsLogic->readProduct();
    }

    public function collectUpdateProduct() {
      $ = $this->ProductsLogic->updateProduct();
    }

    public function collectDeleteProduct() {
      $ = $this->ProductsLogic->deleteProduct();
    }

    public function collectReadAllProducts() {
      $ = $this->ProductsLogic->readProducts();
      include "view/products.php";
  }
}

?>

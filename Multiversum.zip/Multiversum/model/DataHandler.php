<?php

class Datahandler {
    private $host;
    private $dbdriver;
    private $dbname;
    private $username;
    private $password;
    private $conn;

    public function __construct($dbdriver, $host, $dbname, $username, $password) {
      $this->host = $host;
      $this->dbdriver = $dbdriver;
      $this->dbname = $dbname;
      $this->username = $username;
      $this->password = $password;
        try {
            $this->conn = new PDO("$dbdriver:host=$host;dbname=$dbname", $username, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            if ($this->conn==true) {
            echo "Connect <br>";
            } else {
              echo "U FAILED IDIOT LMAO";
            }
        }
        catch(PDOException $e) {
            echo "Connection with ".$this->dbdriver." failed: ".$e->getMessage();
        }


    }
    public function CreateData($sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
    }

    public function ReadData($sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function UpdateData($sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
    }

    public function DeleteData($sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function createForm($sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
}
?>

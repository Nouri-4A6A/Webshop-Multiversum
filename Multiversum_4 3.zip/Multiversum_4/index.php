<?php
  require_once 'controller/MultiversumController.php';


  $product = new MultiversumController();
  $product->handleRequest();
  //var_dump($product);
 ?>

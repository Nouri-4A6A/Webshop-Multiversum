<?php
  require_once 'model/MultiversumLogic.php';

  class MultiversumController {
    public function __construct() {
      $this->MultiversumLogic = new MultiversumLogic();
}

  public function handleRequest() {

    if (isset($_GET['view'])) {
      $view = $_GET['view'];

    } else {

      $view = '';
    }

    switch ($view) {
      case 'home':
          $this->collect_home();
          echo "Dit is de homepagina";
          break;
      case 'catalogus':
          $this->collect_catalogus();
          // echo "Alle producten";
          break;
      case 'contact':
          $this->collect_contact();
          echo "contact pagina";
          break;
      case 'search';
          $this->collect_search();
        break;
      case 'page';
          $this->collect_page();
        break;
      case 'product':
          $this->collect_product();
        break;
      default:
          $this->collect_home();
          break;
        }
    }
    public function collect_home() {
      $products = $this->MultiversumLogic->collect_pagina();
      include 'view/homepage.php';
    }

    public function collect_catalogus() {
      $products = $this->MultiversumLogic->collect_catalogus();
      ($products);
      include 'view/catalogus.php';
    }
    public function collect_product() {
      $products = $this->MultiversumLogic->get_product();
      ($products);
      include 'view/productpage.php';
    }

    public function collect_contact() {
      $products = $this->MultiversumLogic->multi_contact();
    }
    public function collect_search() {
      $products = $this->MultiversumLogic->get_search();
      ($products);
      include 'view/catalogus.php';
    }
    public function collect_page() {
      $products = $this->MultiversumLogic->controller_page();
      include 'view/homepage.php';
    }
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Over ons</title>
      <link rel="stylesheet" type="text/css" href="../styles/style.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <a href="index.php"><img class="logo" src="../styles/Multiversum-logo.png"><a/>
    <a href="view/winkelwagen.php"><img class="shoppingcart" src="../styles/winkelwagen.jpg" href="winkelwagen.php"></a>
    <form class="example" action="#homepage.html">
      <input type="text" placeholder="Klik hier wat u wilt zoeken..." name="search" src="index.php?view=search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
      <ul>
        <li><a href="../index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
        <li><a href="../index.php?view=catalogus">Catalogus</a></li>
        <!-- <li><a href="overons.php">Over ons</a></li> -->
        <li><a href="contact.php">Contact</a></li>
      </ul>
      <img style="width: 500px;"src="../styles/BOOq7hk.gif">
  </body>
    <!-- <?php include "footer.php";?> -->
</html>

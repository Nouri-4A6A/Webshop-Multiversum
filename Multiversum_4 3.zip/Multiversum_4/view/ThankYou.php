<?php  ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Home</title>
      <link rel="stylesheet" type="text/css" href="../styles/style.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <a href="index.php">
    <img class="logo" src="../styles/Multiversum-logo.png">
    </a>
    <a href="view/winkelwagen.php"><img class="shoppingcart" src="../styles/winkelwagen.jpg"></a>
    <form class="example" action="#homepage.html">
      <input type="text" placeholder="Klik hier wat u wilt zoeken..." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
      <ul>
        <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
        <li><a href="catalogus.php">Catalogus</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
      <h3>Wij zullen u zo via e-mail zo snel mogelijk contacteren.</h3>
         <?php
        var_dump($_POST);?>
  </body>
      <footer>
        <?php include "footer.php";?>
      </footer>
</html>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Catalogus</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <a href="view/winkelwagen.php"><img class="shoppingcart" src="styles/winkelwagen.jpg"></a>
    <a href="index.php"><img class="logo" src="styles/Multiversum-logo.png"></a>
    <!-- <a href="view/winkelwagen.php"><img class="shoppingcart" src="index.php?view=search" href="winkelwagen.php"></a> -->
    <form class="example" method="post" action="index.php?view=search">
      <input name="search" type="text" placeholder="Klik hier wat u wilt zoeken..." name="search">
      <button name"submit" type="submit"><i class="fa fa-search"></i></button>
    </form>
      <ul>
        <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
        <li><a href="index.php?view=catalogus">Catalogus</a></li>
        <!-- <li><a href="view/overons.php">Over ons</a></li> -->
        <li><a href="view/contact.php">Contact</a></li>
      </ul>

    <main style="width: 100%; clear: both;">
      <?php echo ($products); ?>
    </main>
        <!-- <?php include "footer.php";
        //var_dump($product);
        //require '../model/DataHandler.php';
        ?> -->
  </body>
</html>


  <footer class="footer">
      <p>
        Contactgegevens:
        <br>
        Multiversum
        <br>
        Adres:
        Jan Pieterszoon Coenstraat 1861
        Postcode:
        69217 E
        <br>
        Land:
        Nederland
        Tel-nr:
        (656)-976-4980
        E-mail:
        jack.jones@multiversum.com
      </p>
  </footer>

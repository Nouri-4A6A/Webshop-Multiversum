<?php
  require_once 'model/MultiversumLogic.php';

  class MultiversumController {
    public function __construct() {
      $this->MultiversumLogic = new MultiversumLogic();
}

  public function handleRequest() {

    if (isset($_GET['view'])) {
      $view = $_GET['view'];

    } else {

      $view = '';
    }

    switch ($view) {
      case 'home':
          $this->collect_home();
          echo "Dit is de homepagina";
          break;
      case 'catalogus':
          $this->collect_catalogus();
          echo "Alle producten";
          break;
      case 'contact':
          $this->collect_contact();
          echo "contact pagina";
          break;
      default:
          $this->collect_home();
          break;
        }
    }
    public function collect_home() {
      $products = $this->MultiversumLogic->collect_homepagina();
      include 'view/homepage.php';
      // var_dump($products[0]["picture"]);
    }

    public function collect_catalogus() {
      $products = $this->MultiversumLogic->readProducts();
    }

    public function collect_contact() {
      $products = $this->MultiversumLogic->multi_contact();
    }
}

?>

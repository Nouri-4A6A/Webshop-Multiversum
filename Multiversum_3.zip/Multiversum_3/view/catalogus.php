<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>title</title>
      <link rel="stylesheet" type="text/css" href="../styles/style.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <img class="logo" src="../styles/Multiversum-logo.png">
    <form class="example" action="#homepage.html">
      <input type="text" placeholder="Klik hier wat u wilt zoeken..." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
      <ul>
        <li><a href="../index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
        <li><a href="catalogus.php">Catalogus</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="overons.php">Over ons</a></li>
      </ul>
        <?php include "footer.php";?>
  </body>
</html>

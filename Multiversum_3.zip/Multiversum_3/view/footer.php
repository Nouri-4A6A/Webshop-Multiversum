<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>title</title>
      <link rel="stylesheet" type="text/css" href="styles/style.css">
    </head>
<body>
  <div class="footer">
    <p>Footer</p>
    <table><th>Contact gegevens</th>
      <td>Laantje zonder eind 235</td>
      <td>3000OP</td>
      <td>Langebroek</td>
    </table>
  </div>
</body>
</html>

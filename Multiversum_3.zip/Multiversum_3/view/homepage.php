<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>title</title>
      <link rel="stylesheet" type="text/css" href="styles/style.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <img class="logo" src="styles/Multiversum-logo.png">
    <form class="example" action="#homepage.html">
      <input type="text" placeholder="Klik hier wat u wilt zoeken..." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
      <ul>
        <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
        <li><a href="view/catalogus.php">Catalogus</a></li>
        <li><a href="view/contact.php">Contact</a></li>
        <li><a href="view/overons.php">Over ons</a></li>
      </ul>
      <div class="div">
        <img src="<?php echo($products[0]["picture"])?>">
         <?php echo($products[0]["product_name"])?>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div">
        <img src="<?php echo($products[1]["picture"])?>">
        <?php echo($products[1]["product_name"])?>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div">
        <img src="<?php echo($products[2]["picture"])?>">
        <?php echo($products[2]["product_name"])?>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div">
        <img src="<?php echo($products[3]["picture"])?>">
        <?php echo($products[3]["product_name"])?>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div">
        <img src="<?php echo($products[4]["picture"])?>">
        <?php echo($products[6]["product_name"])?>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div">
        <img src="<?php echo($products[5]["picture"])?>">
        <?php echo($products[5]["product_name"])?>
        <button class="detailknop">Zie meer</button>
      </div>
      <?php include "footer.php";?>
  </body>
</html>

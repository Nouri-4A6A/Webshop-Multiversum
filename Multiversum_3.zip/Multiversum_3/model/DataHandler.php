<?php
class DataHandler {

  public $servername;
  public $username;
  public $password;
  public $dbname;
  public $conn;

    public function __construct($servername, $username, $password, $dbname){
      $this->servername = $servername;
      $this->username = $username;
      $this->password = $password;
      $this->dbname = $dbname;
        try {
          $this->conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
          $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            if ($this->conn == TRUE) {
              echo "";
            } else {
              echo "Database niet goed geconnect a neef";
            }
        }
        catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
    }

    public function CreateData($sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
    }

    public function ReadData($sql) {
      $stmt = $this->conn->prepare($sql);
      $stmt->execute();
      $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return $result;
    }

    public function UpdateData($sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
    }
    public function DeleteData($id, $sql) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();

    }
    public function createForm($sql){
      $stmt = $this->conn->prepare($sql);
      $stmt->execute();
      $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return $result;
    }
}
  ?>

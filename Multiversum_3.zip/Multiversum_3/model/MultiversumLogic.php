<?php
require_once 'DataHandler.php';
class MultiversumLogic {
  public function __construct(){
    $this->conn = new Datahandler("localhost","stardunk","nouri","Multiversum");
  }
  public function createProduct() {
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $platform = $_POST['platform'];
    $review = $_POST['review'];

    $sql = "INSERT INTO `vr-brillen`(`product_name`, `price`, `brand`, `description`, `platform`, `review`)
    VALUES (`$fproduct_name`, `$fprice`, `$fbrand`, `$fdescription`, '$fplatform', '$freview')";
    $res = $this->conn->CreateData($sql);
    return $this->DataHandler->CreateData();
  }
  public function collect_homepagina(){
    //$sql = "SELECT `product_name`, `price` FROM `vr-brillen` ORDER BY `price` DESC LIMIT 6 ";
    $sql = "SELECT * FROM `vr-brillen`";
    $res = $this->conn->ReadData($sql);
    return $res;
  }
}
?>

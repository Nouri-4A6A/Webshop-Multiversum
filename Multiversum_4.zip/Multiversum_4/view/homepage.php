<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Home</title>
      <link rel="stylesheet" type="text/css" href="styles/style.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <a href="index.php">
    <img class="logo" src="styles/Multiversum-logo.png">
    </a>
    <a href="view/winkelwagen.php"><img class="shoppingcart" src="styles/winkelwagen.jpg"></a>
    <form class="example" method="post" action="searchresults.php">
      <input name="search" type="text" placeholder="Klik hier wat u wilt zoeken..." name="search">
      <button name"submit" type="submit"><i class="fa fa-search"></i></button>
    </form>
      <ul>
        <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
        <li><a href="index.php?view=catalogus">Catalogus</a></li>
        <!-- <li><a href="view/overons.php">Over ons</a></li> -->
        <li><a href="view/contact.php">Contact</a></li>
      </ul>
      <div class="div col-3">
        <img src="<?php echo($products[16]["picture"])?>">
        <br>
        <?php echo($products[15]["product_name"])?>
        <br>
        <strike style="color: red;">9.99</strike>
        <?php echo("€" .$products[15]["price"])?>
        <br>
        <br>
        <button class="detailknop">Zie meer</button>
        </div>
      <div class="div col-3">
        <img src="<?php echo($products[17]["picture"])?>">
        <br>
        <?php echo($products[17]["product_name"])?>
        <br>
        <strike style="color: red;">14.99</strike>
        <?php echo("€" .$products[17]["price"])?>
        <br>
        <br>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div col-3">
        <img src="<?php echo($products[18]["picture"])?>">
        <br>
        <?php echo($products[18]["product_name"])?>
        <br>
        <strike style="color: red;">29.99</strike>
        <?php echo("€" .$products[18]["price"])?>
        <br>
        <br>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div col-3">
        <img src="<?php echo($products[14]["picture"])?>">
        <br>
        <?php echo($products[14]["product_name"])?>
        <br>
        <strike style="color: red;">37.98</strike>
        <?php echo("€" .$products[14]["price"])?>
        <br>
        <br>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div col-3">
        <img src="<?php echo($products[9]["picture"])?>">
        <br>
        <?php echo($products[9]["product_name"])?>
        <br>
        <strike style="color: red;">42.95</strike>
        <?php echo("€" .$products[9]["price"])?>
        <br>
        <br>
        <button class="detailknop">Zie meer</button>
      </div>
      <div class="div col-3">
        <img src="<?php echo($products[8]["picture"])?>">
        <br>
        <?php echo($products[8]["product_name"])?>
        <br>
        <strike style="color: red;">50.00</strike>
        <?php echo("€" .$products[8]["price"])?>
        <br>
        <br>
        <button class="detailknop">Zie meer</button>
      </div>
      <!-- <?php include "footer.php";?> -->
</html>

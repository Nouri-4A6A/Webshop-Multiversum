<?php
require_once 'DataHandler.php';
class MultiversumLogic {
  public function __construct(){
    $this->conn = new Datahandler("localhost","stardunk","nouri","Multiversum");
  }
  public function createProduct() {
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $platform = $_POST['platform'];
    $review = $_POST['review'];

    $sql = "INSERT INTO `vr-brillen`(`product_name`, `price`, `brand`, `description`, `platform`, `review`)
    VALUES (`$fproduct_name`, `$fprice`, `$fbrand`, `$fdescription`, '$fplatform', '$freview')";
    $res = $this->conn->CreateData($sql);
    return $this->DataHandler->CreateData();
  }
  public function collect_pagina(){
    $sql = "SELECT * FROM `vr-brillen`";
    $res = $this->conn->ReadData($sql);
    return $res;
  }
  public function collect_catalogus(){
    $sql = "SELECT * FROM `vr-brillen`";
    $res = $this->conn->ReadData($sql);
    return $this->createBoxes($res);
  }

  public function createBoxes($products) {
  $boxes = "";
  for ($i=0; $i < count($products); $i++) {
    $boxes .= "<div class='div col-3'>
      <img src='" . $products[$i]['picture'] . "'>
      <br>
      " . $products[$i]['product_name'] . "
      <br>
      " . "€" . $products[$i]['price'] . "
      <br>
      <br>
      <button class='detailknop'>Zie meer</button>
    </div>";
    }
    return $boxes;
  }
  public function get_search() {
    $sql = "SELECT * FROM `vr-brillen` WHERE `product_name` LIKE '%".$_POST['search']."%'
    OR brand LIKE '%".$_POST['search']."%' OR description LIKE '%".$_POST['search']."%'";
    $res = $this->conn->ReadData($sql);
    return $this->createBoxes($res);

  }
}
?>
